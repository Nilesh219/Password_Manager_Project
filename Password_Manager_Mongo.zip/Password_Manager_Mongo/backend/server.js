const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');  // Import ObjectId for MongoDB
const bodyParser = require('body-parser');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

// MongoDB connection URI and database name from environment variables
const mongoURI = process.env.MONGO_URI;
const dbName = process.env.DB_NAME;

// Initialize MongoDB client
const client = new MongoClient(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });

client.connect()
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((err) => {
    console.error('Failed to connect to MongoDB:', err);
    process.exit(1); // Exit the app if MongoDB connection fails
  });

// Create an Express app
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Route to get all passwords
app.get('/', async (req, res) => {
  try {
    const db = client.db(dbName);
    const collection = db.collection('passwords');
    const passwords = await collection.find({}).toArray();
    res.json(passwords);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch passwords', error: err.message });
  }
});

// Route to save a password
app.post('/', async (req, res) => {
  try {
    const password = req.body;
    const db = client.db(dbName);
    const collection = db.collection('passwords');
    const result = await collection.insertOne(password);
    res.json({ success: true, result });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to save password', error: err.message });
  }
});

// Route to delete a password by ID
app.delete('/', async (req, res) => {
  try {
    const { id } = req.body; // Assuming the request body contains an `id` field
    if (!id) {
      return res.status(400).json({ success: false, message: 'ID is required' });
    }

    const db = client.db(dbName);
    const collection = db.collection('passwords');
    const deleteResult = await collection.deleteOne({ _id: new ObjectId(id) });

    if (deleteResult.deletedCount === 0) {
      return res.status(404).json({ success: false, message: 'Password not found' });
    }

    res.json({ success: true, message: 'Password deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete password', error: err.message });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
